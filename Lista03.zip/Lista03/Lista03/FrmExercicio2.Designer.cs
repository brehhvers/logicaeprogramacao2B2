﻿namespace Lista03
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtQuantR = new System.Windows.Forms.TextBox();
            this.lblQuantR = new System.Windows.Forms.Label();
            this.lblValorL = new System.Windows.Forms.Label();
            this.txtValorL = new System.Windows.Forms.TextBox();
            this.lblQuantL = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblExercicio2 = new System.Windows.Forms.Label();
            this.pnlMeio = new System.Windows.Forms.Panel();
            this.pnlBaixo = new System.Windows.Forms.Panel();
            this.pnlResult = new System.Windows.Forms.Panel();
            this.lblResult = new System.Windows.Forms.Label();
            this.pnlTopo.SuspendLayout();
            this.pnlMeio.SuspendLayout();
            this.pnlBaixo.SuspendLayout();
            this.pnlResult.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtQuantR
            // 
            this.txtQuantR.Location = new System.Drawing.Point(30, 57);
            this.txtQuantR.Name = "txtQuantR";
            this.txtQuantR.Size = new System.Drawing.Size(100, 20);
            this.txtQuantR.TabIndex = 0;
            this.txtQuantR.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblQuantR
            // 
            this.lblQuantR.AutoSize = true;
            this.lblQuantR.Font = new System.Drawing.Font("Yu Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantR.ForeColor = System.Drawing.Color.AliceBlue;
            this.lblQuantR.Location = new System.Drawing.Point(26, 23);
            this.lblQuantR.Name = "lblQuantR";
            this.lblQuantR.Size = new System.Drawing.Size(334, 21);
            this.lblQuantR.TabIndex = 1;
            this.lblQuantR.Text = "Quantidade em Real que deseja abastaecer";
            this.lblQuantR.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblValorL
            // 
            this.lblValorL.AutoSize = true;
            this.lblValorL.Font = new System.Drawing.Font("Yu Gothic", 12F);
            this.lblValorL.ForeColor = System.Drawing.Color.AliceBlue;
            this.lblValorL.Location = new System.Drawing.Point(27, 111);
            this.lblValorL.Name = "lblValorL";
            this.lblValorL.Size = new System.Drawing.Size(173, 21);
            this.lblValorL.TabIndex = 2;
            this.lblValorL.Text = "Valor do litro em reais";
            this.lblValorL.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txtValorL
            // 
            this.txtValorL.Location = new System.Drawing.Point(30, 145);
            this.txtValorL.Name = "txtValorL";
            this.txtValorL.Size = new System.Drawing.Size(100, 20);
            this.txtValorL.TabIndex = 3;
            // 
            // lblQuantL
            // 
            this.lblQuantL.AutoSize = true;
            this.lblQuantL.Font = new System.Drawing.Font("Yu Gothic", 12F);
            this.lblQuantL.Location = new System.Drawing.Point(155, 26);
            this.lblQuantL.Name = "lblQuantL";
            this.lblQuantL.Size = new System.Drawing.Size(250, 21);
            this.lblQuantL.TabIndex = 4;
            this.lblQuantL.Text = "Quantidade abastecida em litros";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(239, 119);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.BlueViolet;
            this.pnlTopo.Controls.Add(this.lblExercicio2);
            this.pnlTopo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(58)))), ((int)(((byte)(75)))));
            this.pnlTopo.Location = new System.Drawing.Point(0, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(590, 111);
            this.pnlTopo.TabIndex = 7;
            this.pnlTopo.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblExercicio2
            // 
            this.lblExercicio2.AutoSize = true;
            this.lblExercicio2.Font = new System.Drawing.Font("Segoe Print", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(34)))), ((int)(((byte)(68)))));
            this.lblExercicio2.Location = new System.Drawing.Point(19, 22);
            this.lblExercicio2.Name = "lblExercicio2";
            this.lblExercicio2.Size = new System.Drawing.Size(234, 65);
            this.lblExercicio2.TabIndex = 0;
            this.lblExercicio2.Text = "Exercício 2";
            // 
            // pnlMeio
            // 
            this.pnlMeio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(31)))), ((int)(((byte)(71)))));
            this.pnlMeio.Controls.Add(this.lblQuantR);
            this.pnlMeio.Controls.Add(this.txtQuantR);
            this.pnlMeio.Controls.Add(this.txtValorL);
            this.pnlMeio.Controls.Add(this.lblValorL);
            this.pnlMeio.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnlMeio.Location = new System.Drawing.Point(0, 111);
            this.pnlMeio.Name = "pnlMeio";
            this.pnlMeio.Size = new System.Drawing.Size(590, 203);
            this.pnlMeio.TabIndex = 8;
            // 
            // pnlBaixo
            // 
            this.pnlBaixo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(96)))), ((int)(((byte)(206)))));
            this.pnlBaixo.Controls.Add(this.pnlResult);
            this.pnlBaixo.Controls.Add(this.lblQuantL);
            this.pnlBaixo.Controls.Add(this.btnCalcular);
            this.pnlBaixo.Location = new System.Drawing.Point(0, 314);
            this.pnlBaixo.Name = "pnlBaixo";
            this.pnlBaixo.Size = new System.Drawing.Size(590, 157);
            this.pnlBaixo.TabIndex = 9;
            // 
            // pnlResult
            // 
            this.pnlResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(86)))), ((int)(((byte)(207)))), ((int)(((byte)(225)))));
            this.pnlResult.Controls.Add(this.lblResult);
            this.pnlResult.Location = new System.Drawing.Point(159, 65);
            this.pnlResult.Name = "pnlResult";
            this.pnlResult.Size = new System.Drawing.Size(246, 36);
            this.pnlResult.TabIndex = 7;
            // 
            // lblResult
            // 
            this.lblResult.Font = new System.Drawing.Font("Open Sans", 16F, System.Drawing.FontStyle.Bold);
            this.lblResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(0)))), ((int)(((byte)(184)))));
            this.lblResult.Location = new System.Drawing.Point(3, 3);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(240, 30);
            this.lblResult.TabIndex = 0;
            this.lblResult.Text = "0";
            this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 468);
            this.Controls.Add(this.pnlBaixo);
            this.Controls.Add(this.pnlMeio);
            this.Controls.Add(this.pnlTopo);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlMeio.ResumeLayout(false);
            this.pnlMeio.PerformLayout();
            this.pnlBaixo.ResumeLayout(false);
            this.pnlBaixo.PerformLayout();
            this.pnlResult.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtQuantR;
        private System.Windows.Forms.Label lblQuantR;
        private System.Windows.Forms.Label lblValorL;
        private System.Windows.Forms.TextBox txtValorL;
        private System.Windows.Forms.Label lblQuantL;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label lblExercicio2;
        private System.Windows.Forms.Panel pnlMeio;
        private System.Windows.Forms.Panel pnlBaixo;
        private System.Windows.Forms.Panel pnlResult;
        private System.Windows.Forms.Label lblResult;
    }
}