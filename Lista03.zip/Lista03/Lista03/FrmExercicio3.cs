﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void FrmExercicio3_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Variáveis
            float varPeso = float.Parse(txtPeso.Text);

            //Conta
            float varPagamento = varPeso * 34;
            

            //Saída
            lblResult.Text = (varPagamento.ToString("C"));
        }

        private void lblExercicio3_Click(object sender, EventArgs e)
        {

        }
    }
}
