﻿namespace Lista03
{
    partial class FrmExercicio1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum1 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnPorcent = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.lblResultSoma = new System.Windows.Forms.Label();
            this.lblResultMedia = new System.Windows.Forms.Label();
            this.lblResultPorcent = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(42, 104);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(35, 13);
            this.lblNum1.TabIndex = 0;
            this.lblNum1.Text = "Num1";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(45, 136);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(100, 20);
            this.txtNum1.TabIndex = 1;
            this.txtNum1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(189, 104);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(35, 13);
            this.lblNum2.TabIndex = 2;
            this.lblNum2.Text = "Num2";
            this.lblNum2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.Location = new System.Drawing.Point(325, 104);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(35, 13);
            this.lblNum3.TabIndex = 3;
            this.lblNum3.Text = "Num3";
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(192, 136);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(100, 20);
            this.txtNum2.TabIndex = 4;
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(328, 136);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(100, 20);
            this.txtNum3.TabIndex = 5;
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(70, 225);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(75, 23);
            this.btnSoma.TabIndex = 6;
            this.btnSoma.Text = "Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnPorcent
            // 
            this.btnPorcent.Location = new System.Drawing.Point(328, 225);
            this.btnPorcent.Name = "btnPorcent";
            this.btnPorcent.Size = new System.Drawing.Size(85, 23);
            this.btnPorcent.TabIndex = 7;
            this.btnPorcent.Text = "Porcentagem";
            this.btnPorcent.UseVisualStyleBackColor = true;
            this.btnPorcent.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(206, 225);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(75, 23);
            this.btnMedia.TabIndex = 8;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // lblResultSoma
            // 
            this.lblResultSoma.AutoSize = true;
            this.lblResultSoma.Location = new System.Drawing.Point(42, 307);
            this.lblResultSoma.Name = "lblResultSoma";
            this.lblResultSoma.Size = new System.Drawing.Size(89, 13);
            this.lblResultSoma.TabIndex = 9;
            this.lblResultSoma.Text = "Resultado soma: ";
            // 
            // lblResultMedia
            // 
            this.lblResultMedia.AutoSize = true;
            this.lblResultMedia.Location = new System.Drawing.Point(42, 334);
            this.lblResultMedia.Name = "lblResultMedia";
            this.lblResultMedia.Size = new System.Drawing.Size(89, 13);
            this.lblResultMedia.TabIndex = 10;
            this.lblResultMedia.Text = "Resultado média:";
            // 
            // lblResultPorcent
            // 
            this.lblResultPorcent.AutoSize = true;
            this.lblResultPorcent.Location = new System.Drawing.Point(42, 361);
            this.lblResultPorcent.Name = "lblResultPorcent";
            this.lblResultPorcent.Size = new System.Drawing.Size(126, 13);
            this.lblResultPorcent.TabIndex = 11;
            this.lblResultPorcent.Text = "Resultado porcentagem: ";
            this.lblResultPorcent.Click += new System.EventHandler(this.lblResultPorcent_Click);
            // 
            // FrmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 412);
            this.Controls.Add(this.lblResultPorcent);
            this.Controls.Add(this.lblResultMedia);
            this.Controls.Add(this.lblResultSoma);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnPorcent);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum1);
            this.Name = "FrmExercicio1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnPorcent;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Label lblResultSoma;
        private System.Windows.Forms.Label lblResultMedia;
        private System.Windows.Forms.Label lblResultPorcent;
    }
}

