﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Porcentagem de cada número em relação ao total.
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float total, porcNum1, porcNum2, porcNum3;

            //Processo
            total = num1 + num2 + num3;
            porcNum1 = num1 / total;
            porcNum2 = num2 / total;
            porcNum3 = num3 / total;

            //Resultado
            lblResultPorcent.Text = ("Resultado porcentagem: " + porcNum1 + "%, " + porcNum2 + "%, " + porcNum3 + "%");
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            //Pegar da tela os valores
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;

            //Processo
            media = (num1 + num2 + num3) / 3;

            //Saída
            lblResultMedia.Text = ("Resultado média: " + media);
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            //Pegar da tela os valores
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            //Processamento
            soma = num1 + num3;

            //Saída
            lblResultSoma.Text = ("Resultado soma: " + soma);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lblResultPorcent_Click(object sender, EventArgs e)
        {

        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
          
        }
    }
}
