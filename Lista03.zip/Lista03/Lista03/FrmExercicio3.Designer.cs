﻿namespace Lista03
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.pnlMeio = new System.Windows.Forms.Panel();
            this.pnlBaixo = new System.Windows.Forms.Panel();
            this.lblExercicio3 = new System.Windows.Forms.Label();
            this.lblPeso = new System.Windows.Forms.Label();
            this.lblValorAPagar = new System.Windows.Forms.Label();
            this.pnlResult = new System.Windows.Forms.Panel();
            this.lblResult = new System.Windows.Forms.Label();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTopo.SuspendLayout();
            this.pnlMeio.SuspendLayout();
            this.pnlBaixo.SuspendLayout();
            this.pnlResult.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(18)))), ((int)(((byte)(31)))));
            this.pnlTopo.Controls.Add(this.lblExercicio3);
            this.pnlTopo.Location = new System.Drawing.Point(1, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(419, 96);
            this.pnlTopo.TabIndex = 0;
            // 
            // pnlMeio
            // 
            this.pnlMeio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(240)))), ((int)(((byte)(213)))));
            this.pnlMeio.Controls.Add(this.btnCalcular);
            this.pnlMeio.Controls.Add(this.txtPeso);
            this.pnlMeio.Controls.Add(this.lblPeso);
            this.pnlMeio.Location = new System.Drawing.Point(1, 86);
            this.pnlMeio.Name = "pnlMeio";
            this.pnlMeio.Size = new System.Drawing.Size(419, 152);
            this.pnlMeio.TabIndex = 1;
            // 
            // pnlBaixo
            // 
            this.pnlBaixo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(155)))), ((int)(((byte)(188)))));
            this.pnlBaixo.Controls.Add(this.pnlResult);
            this.pnlBaixo.Controls.Add(this.lblValorAPagar);
            this.pnlBaixo.Location = new System.Drawing.Point(1, 244);
            this.pnlBaixo.Name = "pnlBaixo";
            this.pnlBaixo.Size = new System.Drawing.Size(419, 207);
            this.pnlBaixo.TabIndex = 2;
            // 
            // lblExercicio3
            // 
            this.lblExercicio3.AutoSize = true;
            this.lblExercicio3.Font = new System.Drawing.Font("Segoe Print", 27.75F, System.Drawing.FontStyle.Bold);
            this.lblExercicio3.Location = new System.Drawing.Point(11, 9);
            this.lblExercicio3.Name = "lblExercicio3";
            this.lblExercicio3.Size = new System.Drawing.Size(261, 65);
            this.lblExercicio3.TabIndex = 0;
            this.lblExercicio3.Text = "Exercício 03";
            this.lblExercicio3.Click += new System.EventHandler(this.lblExercicio3_Click);
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Font = new System.Drawing.Font("Yu Gothic", 12F);
            this.lblPeso.Location = new System.Drawing.Point(128, 17);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(169, 21);
            this.lblPeso.TabIndex = 0;
            this.lblPeso.Text = "Peso da refeição (kg)";
            // 
            // lblValorAPagar
            // 
            this.lblValorAPagar.AutoSize = true;
            this.lblValorAPagar.Font = new System.Drawing.Font("Yu Gothic", 12F);
            this.lblValorAPagar.Location = new System.Drawing.Point(154, 20);
            this.lblValorAPagar.Name = "lblValorAPagar";
            this.lblValorAPagar.Size = new System.Drawing.Size(108, 21);
            this.lblValorAPagar.TabIndex = 5;
            this.lblValorAPagar.Text = "Valor a pagar";
            // 
            // pnlResult
            // 
            this.pnlResult.BackColor = System.Drawing.Color.LightCyan;
            this.pnlResult.Controls.Add(this.lblResult);
            this.pnlResult.Location = new System.Drawing.Point(112, 44);
            this.pnlResult.Name = "pnlResult";
            this.pnlResult.Size = new System.Drawing.Size(200, 28);
            this.pnlResult.TabIndex = 6;
            // 
            // lblResult
            // 
            this.lblResult.Font = new System.Drawing.Font("Open Sans", 16F, System.Drawing.FontStyle.Bold);
            this.lblResult.Location = new System.Drawing.Point(3, 0);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(194, 28);
            this.lblResult.TabIndex = 0;
            this.lblResult.Text = "0";
            this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPeso
            // 
            this.txtPeso.Font = new System.Drawing.Font("Open Sans", 14F, System.Drawing.FontStyle.Bold);
            this.txtPeso.Location = new System.Drawing.Point(91, 41);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(230, 33);
            this.txtPeso.TabIndex = 2;
            this.txtPeso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(73)))));
            this.btnCalcular.Font = new System.Drawing.Font("Yu Gothic", 10F);
            this.btnCalcular.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnCalcular.Location = new System.Drawing.Point(158, 89);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(98, 34);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 344);
            this.Controls.Add(this.pnlBaixo);
            this.Controls.Add(this.pnlMeio);
            this.Controls.Add(this.pnlTopo);
            this.Name = "FrmExercicio3";
            this.Text = "FrmExercicio3";
            this.Load += new System.EventHandler(this.FrmExercicio3_Load);
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlMeio.ResumeLayout(false);
            this.pnlMeio.PerformLayout();
            this.pnlBaixo.ResumeLayout(false);
            this.pnlBaixo.PerformLayout();
            this.pnlResult.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Panel pnlMeio;
        private System.Windows.Forms.Panel pnlBaixo;
        private System.Windows.Forms.Label lblExercicio3;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Panel pnlResult;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblValorAPagar;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.Button btnCalcular;
    }
}