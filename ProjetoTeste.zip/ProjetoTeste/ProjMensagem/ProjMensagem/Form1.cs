﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjMensagem
{
    public partial class Mensagens : Form
    {
        public Mensagens()
        {
            InitializeComponent();
        }

        private void Mensagens_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Abrindo formulário)");
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mostrando resultados");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Deseja limpar?");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Texto alterado com sucesso ^^");
        }
    }
}
