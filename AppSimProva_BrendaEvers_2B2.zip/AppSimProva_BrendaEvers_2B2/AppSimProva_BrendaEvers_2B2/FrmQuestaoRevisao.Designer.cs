﻿namespace AppSimProva_BrendaEvers_2B2
{
    partial class FrmQuestaoRevisao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblRevisao = new System.Windows.Forms.Label();
            this.pnlResultado = new System.Windows.Forms.Panel();
            this.pnlFundoTabela = new System.Windows.Forms.Panel();
            this.pnl32 = new System.Windows.Forms.Panel();
            this.lblResultVal3 = new System.Windows.Forms.Label();
            this.pnl22 = new System.Windows.Forms.Panel();
            this.lblResultVal2 = new System.Windows.Forms.Label();
            this.pnl12 = new System.Windows.Forms.Panel();
            this.lblResultVal1 = new System.Windows.Forms.Label();
            this.pnl31 = new System.Windows.Forms.Panel();
            this.lblTextoVal3 = new System.Windows.Forms.Label();
            this.pnl21 = new System.Windows.Forms.Panel();
            this.lblTextoVal2 = new System.Windows.Forms.Label();
            this.pnl11 = new System.Windows.Forms.Panel();
            this.lblTextoVal1 = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblVal1 = new System.Windows.Forms.Label();
            this.txtVal1 = new System.Windows.Forms.TextBox();
            this.lblVal2 = new System.Windows.Forms.Label();
            this.txtVal2 = new System.Windows.Forms.TextBox();
            this.txtVal3 = new System.Windows.Forms.TextBox();
            this.lblVal3 = new System.Windows.Forms.Label();
            this.pnlCorpo = new System.Windows.Forms.Panel();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblInsira = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.pnlTopo.SuspendLayout();
            this.pnlResultado.SuspendLayout();
            this.pnlFundoTabela.SuspendLayout();
            this.pnl32.SuspendLayout();
            this.pnl22.SuspendLayout();
            this.pnl12.SuspendLayout();
            this.pnl31.SuspendLayout();
            this.pnl21.SuspendLayout();
            this.pnl11.SuspendLayout();
            this.pnlCorpo.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(181)))), ((int)(((byte)(101)))), ((int)(((byte)(118)))));
            this.pnlTopo.Controls.Add(this.btnLimpar);
            this.pnlTopo.Controls.Add(this.lblRevisao);
            this.pnlTopo.Location = new System.Drawing.Point(6, 5);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(788, 96);
            this.pnlTopo.TabIndex = 0;
            this.pnlTopo.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlTopo_Paint);
            // 
            // lblRevisao
            // 
            this.lblRevisao.AutoSize = true;
            this.lblRevisao.Font = new System.Drawing.Font("Open Sans", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevisao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(29)))), ((int)(((byte)(49)))));
            this.lblRevisao.Location = new System.Drawing.Point(23, 24);
            this.lblRevisao.Name = "lblRevisao";
            this.lblRevisao.Size = new System.Drawing.Size(178, 55);
            this.lblRevisao.TabIndex = 0;
            this.lblRevisao.Text = "Revisão";
            // 
            // pnlResultado
            // 
            this.pnlResultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(89)))), ((int)(((byte)(122)))));
            this.pnlResultado.Controls.Add(this.pnlFundoTabela);
            this.pnlResultado.Controls.Add(this.lblResultado);
            this.pnlResultado.Location = new System.Drawing.Point(344, 107);
            this.pnlResultado.Name = "pnlResultado";
            this.pnlResultado.Size = new System.Drawing.Size(450, 339);
            this.pnlResultado.TabIndex = 1;
            // 
            // pnlFundoTabela
            // 
            this.pnlFundoTabela.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(32)))), ((int)(((byte)(56)))));
            this.pnlFundoTabela.Controls.Add(this.pnl32);
            this.pnlFundoTabela.Controls.Add(this.pnl22);
            this.pnlFundoTabela.Controls.Add(this.pnl12);
            this.pnlFundoTabela.Controls.Add(this.pnl31);
            this.pnlFundoTabela.Controls.Add(this.pnl21);
            this.pnlFundoTabela.Controls.Add(this.pnl11);
            this.pnlFundoTabela.Location = new System.Drawing.Point(18, 77);
            this.pnlFundoTabela.Name = "pnlFundoTabela";
            this.pnlFundoTabela.Size = new System.Drawing.Size(413, 232);
            this.pnlFundoTabela.TabIndex = 10;
            // 
            // pnl32
            // 
            this.pnl32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(106)))), ((int)(((byte)(174)))));
            this.pnl32.Controls.Add(this.lblResultVal3);
            this.pnl32.Location = new System.Drawing.Point(263, 163);
            this.pnl32.Name = "pnl32";
            this.pnl32.Size = new System.Drawing.Size(134, 54);
            this.pnl32.TabIndex = 2;
            // 
            // lblResultVal3
            // 
            this.lblResultVal3.Font = new System.Drawing.Font("Open Sans Semibold", 10.25F, System.Drawing.FontStyle.Bold);
            this.lblResultVal3.Location = new System.Drawing.Point(22, 18);
            this.lblResultVal3.Name = "lblResultVal3";
            this.lblResultVal3.Size = new System.Drawing.Size(96, 19);
            this.lblResultVal3.TabIndex = 12;
            this.lblResultVal3.Text = "-";
            this.lblResultVal3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl22
            // 
            this.pnl22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(106)))), ((int)(((byte)(174)))));
            this.pnl22.Controls.Add(this.lblResultVal2);
            this.pnl22.Location = new System.Drawing.Point(263, 89);
            this.pnl22.Name = "pnl22";
            this.pnl22.Size = new System.Drawing.Size(134, 54);
            this.pnl22.TabIndex = 2;
            // 
            // lblResultVal2
            // 
            this.lblResultVal2.Font = new System.Drawing.Font("Open Sans Semibold", 10.25F, System.Drawing.FontStyle.Bold);
            this.lblResultVal2.Location = new System.Drawing.Point(22, 17);
            this.lblResultVal2.Name = "lblResultVal2";
            this.lblResultVal2.Size = new System.Drawing.Size(96, 19);
            this.lblResultVal2.TabIndex = 11;
            this.lblResultVal2.Text = "-";
            this.lblResultVal2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl12
            // 
            this.pnl12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(106)))), ((int)(((byte)(174)))));
            this.pnl12.Controls.Add(this.lblResultVal1);
            this.pnl12.Location = new System.Drawing.Point(263, 12);
            this.pnl12.Name = "pnl12";
            this.pnl12.Size = new System.Drawing.Size(134, 54);
            this.pnl12.TabIndex = 1;
            // 
            // lblResultVal1
            // 
            this.lblResultVal1.Font = new System.Drawing.Font("Open Sans Semibold", 10.25F, System.Drawing.FontStyle.Bold);
            this.lblResultVal1.Location = new System.Drawing.Point(18, 18);
            this.lblResultVal1.Name = "lblResultVal1";
            this.lblResultVal1.Size = new System.Drawing.Size(100, 19);
            this.lblResultVal1.TabIndex = 10;
            this.lblResultVal1.Text = "-";
            this.lblResultVal1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl31
            // 
            this.pnl31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(106)))), ((int)(((byte)(174)))));
            this.pnl31.Controls.Add(this.lblTextoVal3);
            this.pnl31.Location = new System.Drawing.Point(15, 163);
            this.pnl31.Name = "pnl31";
            this.pnl31.Size = new System.Drawing.Size(242, 54);
            this.pnl31.TabIndex = 1;
            // 
            // lblTextoVal3
            // 
            this.lblTextoVal3.AutoSize = true;
            this.lblTextoVal3.Font = new System.Drawing.Font("Open Sans Semibold", 10.25F, System.Drawing.FontStyle.Bold);
            this.lblTextoVal3.Location = new System.Drawing.Point(13, 18);
            this.lblTextoVal3.Name = "lblTextoVal3";
            this.lblTextoVal3.Size = new System.Drawing.Size(216, 19);
            this.lblTextoVal3.TabIndex = 11;
            this.lblTextoVal3.Text = "Valor 3 com acréscimo de 10%";
            // 
            // pnl21
            // 
            this.pnl21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(106)))), ((int)(((byte)(174)))));
            this.pnl21.Controls.Add(this.lblTextoVal2);
            this.pnl21.Location = new System.Drawing.Point(15, 89);
            this.pnl21.Name = "pnl21";
            this.pnl21.Size = new System.Drawing.Size(242, 54);
            this.pnl21.TabIndex = 1;
            // 
            // lblTextoVal2
            // 
            this.lblTextoVal2.AutoSize = true;
            this.lblTextoVal2.Font = new System.Drawing.Font("Open Sans Semibold", 10.25F, System.Drawing.FontStyle.Bold);
            this.lblTextoVal2.Location = new System.Drawing.Point(13, 17);
            this.lblTextoVal2.Name = "lblTextoVal2";
            this.lblTextoVal2.Size = new System.Drawing.Size(216, 19);
            this.lblTextoVal2.TabIndex = 10;
            this.lblTextoVal2.Text = "Valor 2 com acréscimo de 10%";
            // 
            // pnl11
            // 
            this.pnl11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(106)))), ((int)(((byte)(174)))));
            this.pnl11.Controls.Add(this.lblTextoVal1);
            this.pnl11.Location = new System.Drawing.Point(15, 12);
            this.pnl11.Name = "pnl11";
            this.pnl11.Size = new System.Drawing.Size(242, 54);
            this.pnl11.TabIndex = 0;
            // 
            // lblTextoVal1
            // 
            this.lblTextoVal1.AutoSize = true;
            this.lblTextoVal1.Font = new System.Drawing.Font("Open Sans Semibold", 10.25F, System.Drawing.FontStyle.Bold);
            this.lblTextoVal1.Location = new System.Drawing.Point(13, 18);
            this.lblTextoVal1.Name = "lblTextoVal1";
            this.lblTextoVal1.Size = new System.Drawing.Size(216, 19);
            this.lblTextoVal1.TabIndex = 9;
            this.lblTextoVal1.Text = "Valor 1 com acréscimo de 10%";
            this.lblTextoVal1.Click += new System.EventHandler(this.lblTextoVal1_Click_1);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Open Sans Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(162, 29);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(117, 26);
            this.lblResultado.TabIndex = 9;
            this.lblResultado.Text = "Resultados:";
            // 
            // lblVal1
            // 
            this.lblVal1.AutoSize = true;
            this.lblVal1.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVal1.Location = new System.Drawing.Point(27, 89);
            this.lblVal1.Name = "lblVal1";
            this.lblVal1.Size = new System.Drawing.Size(74, 26);
            this.lblVal1.TabIndex = 2;
            this.lblVal1.Text = "Valor 1";
            // 
            // txtVal1
            // 
            this.txtVal1.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVal1.Location = new System.Drawing.Point(32, 118);
            this.txtVal1.Name = "txtVal1";
            this.txtVal1.Size = new System.Drawing.Size(100, 25);
            this.txtVal1.TabIndex = 3;
            // 
            // lblVal2
            // 
            this.lblVal2.AutoSize = true;
            this.lblVal2.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVal2.Location = new System.Drawing.Point(27, 166);
            this.lblVal2.Name = "lblVal2";
            this.lblVal2.Size = new System.Drawing.Size(74, 26);
            this.lblVal2.TabIndex = 4;
            this.lblVal2.Text = "Valor 2";
            // 
            // txtVal2
            // 
            this.txtVal2.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVal2.Location = new System.Drawing.Point(32, 195);
            this.txtVal2.Name = "txtVal2";
            this.txtVal2.Size = new System.Drawing.Size(100, 25);
            this.txtVal2.TabIndex = 5;
            // 
            // txtVal3
            // 
            this.txtVal3.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVal3.Location = new System.Drawing.Point(32, 269);
            this.txtVal3.Name = "txtVal3";
            this.txtVal3.Size = new System.Drawing.Size(100, 25);
            this.txtVal3.TabIndex = 6;
            // 
            // lblVal3
            // 
            this.lblVal3.AutoSize = true;
            this.lblVal3.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVal3.Location = new System.Drawing.Point(27, 240);
            this.lblVal3.Name = "lblVal3";
            this.lblVal3.Size = new System.Drawing.Size(74, 26);
            this.lblVal3.TabIndex = 7;
            this.lblVal3.Text = "Valor 3";
            // 
            // pnlCorpo
            // 
            this.pnlCorpo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(172)))), ((int)(((byte)(139)))));
            this.pnlCorpo.Controls.Add(this.lblInsira);
            this.pnlCorpo.Controls.Add(this.lblVal1);
            this.pnlCorpo.Controls.Add(this.lblVal3);
            this.pnlCorpo.Controls.Add(this.txtVal1);
            this.pnlCorpo.Controls.Add(this.txtVal3);
            this.pnlCorpo.Controls.Add(this.lblVal2);
            this.pnlCorpo.Controls.Add(this.txtVal2);
            this.pnlCorpo.Location = new System.Drawing.Point(7, 107);
            this.pnlCorpo.Name = "pnlCorpo";
            this.pnlCorpo.Size = new System.Drawing.Size(331, 339);
            this.pnlCorpo.TabIndex = 9;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(80)))), ((int)(((byte)(112)))));
            this.btnCalcular.Font = new System.Drawing.Font("Open Sans", 10.25F);
            this.btnCalcular.ForeColor = System.Drawing.Color.White;
            this.btnCalcular.Location = new System.Drawing.Point(6, 452);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(788, 51);
            this.btnCalcular.TabIndex = 9;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblInsira
            // 
            this.lblInsira.AutoSize = true;
            this.lblInsira.Font = new System.Drawing.Font("Open Sans Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInsira.Location = new System.Drawing.Point(27, 29);
            this.lblInsira.Name = "lblInsira";
            this.lblInsira.Size = new System.Drawing.Size(266, 26);
            this.lblInsira.TabIndex = 8;
            this.lblInsira.Text = "Insira os números decimais:";
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(80)))), ((int)(((byte)(112)))));
            this.btnLimpar.Font = new System.Drawing.Font("Open Sans", 10.25F);
            this.btnLimpar.ForeColor = System.Drawing.Color.White;
            this.btnLimpar.Location = new System.Drawing.Point(619, 24);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(134, 51);
            this.btnLimpar.TabIndex = 1;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // FrmQuestaoRevisao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 509);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.pnlCorpo);
            this.Controls.Add(this.pnlResultado);
            this.Controls.Add(this.pnlTopo);
            this.Name = "FrmQuestaoRevisao";
            this.Text = "FrmQuestao02";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlResultado.ResumeLayout(false);
            this.pnlResultado.PerformLayout();
            this.pnlFundoTabela.ResumeLayout(false);
            this.pnl32.ResumeLayout(false);
            this.pnl22.ResumeLayout(false);
            this.pnl12.ResumeLayout(false);
            this.pnl31.ResumeLayout(false);
            this.pnl31.PerformLayout();
            this.pnl21.ResumeLayout(false);
            this.pnl21.PerformLayout();
            this.pnl11.ResumeLayout(false);
            this.pnl11.PerformLayout();
            this.pnlCorpo.ResumeLayout(false);
            this.pnlCorpo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Panel pnlResultado;
        private System.Windows.Forms.Label lblRevisao;
        private System.Windows.Forms.Panel pnlFundoTabela;
        private System.Windows.Forms.Panel pnl32;
        private System.Windows.Forms.Panel pnl22;
        private System.Windows.Forms.Panel pnl12;
        private System.Windows.Forms.Panel pnl31;
        private System.Windows.Forms.Panel pnl21;
        private System.Windows.Forms.Panel pnl11;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblVal1;
        private System.Windows.Forms.TextBox txtVal1;
        private System.Windows.Forms.Label lblVal2;
        private System.Windows.Forms.TextBox txtVal2;
        private System.Windows.Forms.TextBox txtVal3;
        private System.Windows.Forms.Label lblVal3;
        private System.Windows.Forms.Panel pnlCorpo;
        private System.Windows.Forms.Label lblInsira;
        private System.Windows.Forms.Label lblTextoVal1;
        private System.Windows.Forms.Label lblResultVal3;
        private System.Windows.Forms.Label lblResultVal2;
        private System.Windows.Forms.Label lblResultVal1;
        private System.Windows.Forms.Label lblTextoVal3;
        private System.Windows.Forms.Label lblTextoVal2;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
    }
}