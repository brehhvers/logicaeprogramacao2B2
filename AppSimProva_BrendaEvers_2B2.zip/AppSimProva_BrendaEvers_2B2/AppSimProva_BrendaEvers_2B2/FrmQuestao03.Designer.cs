﻿namespace AppSimProva_BrendaEvers_2B2
{
    partial class FrmQuestao03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCabecalho = new System.Windows.Forms.Panel();
            this.lblProximaPag = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlCorpo = new System.Windows.Forms.Panel();
            this.pnlResultado = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtAtraso = new System.Windows.Forms.TextBox();
            this.lblAtraso = new System.Windows.Forms.Label();
            this.txtConsumo = new System.Windows.Forms.TextBox();
            this.lblConsumo = new System.Windows.Forms.Label();
            this.txtValorKWh = new System.Windows.Forms.TextBox();
            this.lblValorKWh = new System.Windows.Forms.Label();
            this.txtNomeEmpresa = new System.Windows.Forms.TextBox();
            this.lblNomeEmpresa = new System.Windows.Forms.Label();
            this.pnlCabecalho.SuspendLayout();
            this.pnlCorpo.SuspendLayout();
            this.pnlResultado.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCabecalho
            // 
            this.pnlCabecalho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(8)))), ((int)(((byte)(20)))));
            this.pnlCabecalho.Controls.Add(this.lblProximaPag);
            this.pnlCabecalho.Controls.Add(this.lblTitulo);
            this.pnlCabecalho.Location = new System.Drawing.Point(6, 12);
            this.pnlCabecalho.Name = "pnlCabecalho";
            this.pnlCabecalho.Size = new System.Drawing.Size(787, 85);
            this.pnlCabecalho.TabIndex = 0;
            // 
            // lblProximaPag
            // 
            this.lblProximaPag.AutoSize = true;
            this.lblProximaPag.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProximaPag.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(223)))), ((int)(((byte)(147)))));
            this.lblProximaPag.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblProximaPag.Location = new System.Drawing.Point(649, 18);
            this.lblProximaPag.Name = "lblProximaPag";
            this.lblProximaPag.Size = new System.Drawing.Size(112, 25);
            this.lblProximaPag.TabIndex = 10;
            this.lblProximaPag.Text = "Próxima ➤";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.CausesValidation = false;
            this.lblTitulo.Font = new System.Drawing.Font("Open Sans", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(195)))), ((int)(((byte)(0)))));
            this.lblTitulo.Location = new System.Drawing.Point(20, 18);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(247, 47);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "ELECTRAQUA";
            this.lblTitulo.Click += new System.EventHandler(this.lblTitulo_Click);
            // 
            // pnlCorpo
            // 
            this.pnlCorpo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(53)))), ((int)(((byte)(102)))));
            this.pnlCorpo.Controls.Add(this.pnlResultado);
            this.pnlCorpo.Controls.Add(this.btnCalcular);
            this.pnlCorpo.Controls.Add(this.txtAtraso);
            this.pnlCorpo.Controls.Add(this.lblAtraso);
            this.pnlCorpo.Controls.Add(this.txtConsumo);
            this.pnlCorpo.Controls.Add(this.lblConsumo);
            this.pnlCorpo.Controls.Add(this.txtValorKWh);
            this.pnlCorpo.Controls.Add(this.lblValorKWh);
            this.pnlCorpo.Controls.Add(this.txtNomeEmpresa);
            this.pnlCorpo.Controls.Add(this.lblNomeEmpresa);
            this.pnlCorpo.Location = new System.Drawing.Point(6, 104);
            this.pnlCorpo.Name = "pnlCorpo";
            this.pnlCorpo.Size = new System.Drawing.Size(787, 337);
            this.pnlCorpo.TabIndex = 1;
            // 
            // pnlResultado
            // 
            this.pnlResultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(45)))));
            this.pnlResultado.Controls.Add(this.lblResultado);
            this.pnlResultado.Controls.Add(this.lblTotal);
            this.pnlResultado.Location = new System.Drawing.Point(384, 254);
            this.pnlResultado.Name = "pnlResultado";
            this.pnlResultado.Size = new System.Drawing.Size(403, 83);
            this.pnlResultado.TabIndex = 9;
            this.pnlResultado.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(10)))));
            this.lblResultado.Location = new System.Drawing.Point(264, 24);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(20, 25);
            this.lblResultado.TabIndex = 11;
            this.lblResultado.Text = "-";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(10)))));
            this.lblTotal.Location = new System.Drawing.Point(19, 24);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(134, 25);
            this.lblTotal.TabIndex = 10;
            this.lblTotal.Text = "Total a pagar";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(160)))), ((int)(((byte)(0)))));
            this.btnCalcular.Font = new System.Drawing.Font("Bahnschrift SemiBold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(28, 272);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(331, 43);
            this.btnCalcular.TabIndex = 8;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtAtraso
            // 
            this.txtAtraso.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAtraso.ForeColor = System.Drawing.Color.DimGray;
            this.txtAtraso.Location = new System.Drawing.Point(561, 182);
            this.txtAtraso.Name = "txtAtraso";
            this.txtAtraso.Size = new System.Drawing.Size(192, 27);
            this.txtAtraso.TabIndex = 7;
            // 
            // lblAtraso
            // 
            this.lblAtraso.AutoSize = true;
            this.lblAtraso.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAtraso.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(10)))));
            this.lblAtraso.Location = new System.Drawing.Point(556, 148);
            this.lblAtraso.Name = "lblAtraso";
            this.lblAtraso.Size = new System.Drawing.Size(149, 25);
            this.lblAtraso.TabIndex = 6;
            this.lblAtraso.Text = "Dias em atraso";
            // 
            // txtConsumo
            // 
            this.txtConsumo.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConsumo.ForeColor = System.Drawing.Color.DimGray;
            this.txtConsumo.Location = new System.Drawing.Point(283, 182);
            this.txtConsumo.Name = "txtConsumo";
            this.txtConsumo.Size = new System.Drawing.Size(192, 27);
            this.txtConsumo.TabIndex = 5;
            // 
            // lblConsumo
            // 
            this.lblConsumo.AutoSize = true;
            this.lblConsumo.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConsumo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(10)))));
            this.lblConsumo.Location = new System.Drawing.Point(278, 148);
            this.lblConsumo.Name = "lblConsumo";
            this.lblConsumo.Size = new System.Drawing.Size(227, 25);
            this.lblConsumo.TabIndex = 4;
            this.lblConsumo.Text = "Quantidade consumida";
            // 
            // txtValorKWh
            // 
            this.txtValorKWh.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorKWh.ForeColor = System.Drawing.Color.DimGray;
            this.txtValorKWh.Location = new System.Drawing.Point(20, 182);
            this.txtValorKWh.Name = "txtValorKWh";
            this.txtValorKWh.Size = new System.Drawing.Size(192, 27);
            this.txtValorKWh.TabIndex = 3;
            // 
            // lblValorKWh
            // 
            this.lblValorKWh.AutoSize = true;
            this.lblValorKWh.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorKWh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(10)))));
            this.lblValorKWh.Location = new System.Drawing.Point(15, 148);
            this.lblValorKWh.Name = "lblValorKWh";
            this.lblValorKWh.Size = new System.Drawing.Size(109, 25);
            this.lblValorKWh.TabIndex = 2;
            this.lblValorKWh.Text = "Valor KWh";
            // 
            // txtNomeEmpresa
            // 
            this.txtNomeEmpresa.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeEmpresa.ForeColor = System.Drawing.Color.DimGray;
            this.txtNomeEmpresa.Location = new System.Drawing.Point(20, 72);
            this.txtNomeEmpresa.Name = "txtNomeEmpresa";
            this.txtNomeEmpresa.Size = new System.Drawing.Size(733, 27);
            this.txtNomeEmpresa.TabIndex = 1;
            // 
            // lblNomeEmpresa
            // 
            this.lblNomeEmpresa.AutoSize = true;
            this.lblNomeEmpresa.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeEmpresa.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(214)))), ((int)(((byte)(10)))));
            this.lblNomeEmpresa.Location = new System.Drawing.Point(15, 38);
            this.lblNomeEmpresa.Name = "lblNomeEmpresa";
            this.lblNomeEmpresa.Size = new System.Drawing.Size(283, 25);
            this.lblNomeEmpresa.TabIndex = 0;
            this.lblNomeEmpresa.Text = "Nome da empresa/residência";
            this.lblNomeEmpresa.Click += new System.EventHandler(this.lblNomeEmpresa_Click);
            // 
            // FrmQuestao03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(242)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlCorpo);
            this.Controls.Add(this.pnlCabecalho);
            this.Name = "FrmQuestao03";
            this.Text = "FrmQuestao03";
            this.Load += new System.EventHandler(this.FrmQuestao03_Load);
            this.pnlCabecalho.ResumeLayout(false);
            this.pnlCabecalho.PerformLayout();
            this.pnlCorpo.ResumeLayout(false);
            this.pnlCorpo.PerformLayout();
            this.pnlResultado.ResumeLayout(false);
            this.pnlResultado.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlCabecalho;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlCorpo;
        private System.Windows.Forms.Label lblNomeEmpresa;
        private System.Windows.Forms.TextBox txtNomeEmpresa;
        private System.Windows.Forms.Panel pnlResultado;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtAtraso;
        private System.Windows.Forms.Label lblAtraso;
        private System.Windows.Forms.TextBox txtConsumo;
        private System.Windows.Forms.Label lblConsumo;
        private System.Windows.Forms.TextBox txtValorKWh;
        private System.Windows.Forms.Label lblValorKWh;
        private System.Windows.Forms.Label lblProximaPag;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblTotal;
    }
}