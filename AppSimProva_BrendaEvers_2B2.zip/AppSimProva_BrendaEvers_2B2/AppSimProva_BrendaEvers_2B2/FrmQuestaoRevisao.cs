﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_BrendaEvers_2B2
{
    public partial class FrmQuestaoRevisao : Form
    {
        public FrmQuestaoRevisao()
        {
            InitializeComponent();
        }

        private void pnlTopo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblTextoVal1_Click(object sender, EventArgs e)
        {

        }

        private void lblTextoVal1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Declaração de vriáveis
            float varVal1 = float.Parse(txtVal1.Text);
            float varVal2 = float.Parse(txtVal2.Text);
            float varVal3 = float.Parse(txtVal3.Text);


            //Cálculo com resultado
            lblResultVal1.Text = (varVal1 * 10 / 100 + varVal1).ToString("C");
            lblResultVal2.Text = (varVal2 * 10 / 100 + varVal2).ToString("C");
            lblResultVal3.Text = (varVal3 * 10 / 100 + varVal3).ToString("C");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtVal1.Clear();
            txtVal2.Clear();
            txtVal3.Clear();
            lblResultVal1.Text = ("-");
            lblResultVal2.Text = ("-");
            lblResultVal3.Text = ("-");
        }
    }
}
